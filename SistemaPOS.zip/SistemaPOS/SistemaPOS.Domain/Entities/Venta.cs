﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SistemaPOS.Domain.Entities
{
    [Table("VENTA")]
    public class Venta
    {
        [Key]
        [Column("VEN_ID")]
        public int VenId { get; set; }

        [Column("FECHA_VENTA")]
        public DateTime FechaVenta { get; set; } = DateTime.Now;

        [Required]
        [Column("VEN_TOTAL")]
        public decimal VenTotal { get; set; }

        [Required]
        [Column("VEN_METODO_PAGO")]
        [StringLength(30)]
        public string VenMetodoPago { get; set; } = string.Empty;

        [Column("CAJA_ID")]
        public int CajaId { get; set; }

        [ForeignKey("CajaId")]
        public Caja? Caja { get; set; }

        public ICollection<DetalleVenta>? Detalles { get; set; }
    }
}
